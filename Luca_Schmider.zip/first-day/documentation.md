# First Day

## Hello, World (Assembler-Version)

The objective in our "Hello, World" programs is to
let an led blink. The `LED should be on` for about `100ms` and `then off` for about `900ms`.

```assembler
    list p=PIC16F877A
    #include <p16F877A.inc>
    
    __CONFIG _CP_OFF & _WDT_OFF & _HS_OSC & _LVP_OFF & _BODEN_OFF
    
DelayTemp	EQU     0x20    ; address of free ram register
RES_VECT    CODE    0x0000  ; processor reset vector
    GOTO    START           ; go to beginning of program

MAIN_PROG CODE              ; let linker place main program
    ;   The specific code of an application goes here
    END
```

We started by creating a new project in MPLAB X and created a file containing the code above. Most of the code will always be the same, but the first three are specific to the target chip (in our case a _PIC16F877A_). We used the `__CONFIG` directive to set some settings for the chip. The fourth line is specific to our code and defines a register used by our delay subroutine. With this alias being set we make it less likely that the register is used by accident.  
To cover this application I will firstly go through all the sub routines that are implemented.

### 1. DelayW

The `DelayW` subroutine delays the further execution of the code by a specified amount of milliseconds. To specify that time we have to use two statements:

```assembler
movlw	    D'100'      ;   move the amount of milliseconds to the accumulator
call	    DelayW      ;   call DelayW to wait the specified time
```

`DelayW` will then use a register and counts that down to zero which delays the execution by the in `W` stored amount of cycles.

### 2. Delay900

As we target a microcontroller that is not capable of handling values greater than `255` we need a workaround for the 900ms duration in which the LED should be turned of. We simply call the `DelayW`-Subroutine for four times and always set duration to `255` which totals to a delay $255ms \bullet 4 = 1020ms$. 

### 3. Initialize for Hello, World

```assembler
Initialize
    bsf	    STATUS,RP0
    movlw   B'11111110'
    movwf   TRISB
    bcf	    STATUS,RP0
    clrf    PORTB
    return
```

In order to use the digital pins we have to set the pin its mode to output. We do that in the third and fourth line of the snippet by writing a byte in the accumulator that has a `0` as its LSB. The LSB is responsible for the pin `0` that we are going to use. The remaining values control other pins in that port, but as we don't use them the values set here are not really important.
The last statement sets the value of all pins in port b to low in case some pins initialized with one.

### 4. Hello, World

```assembler
START
    call        Initialize
    Loop    
    bsf		    PORTB,0
    movlw	    D'100'
    call	    DelayW
    bcf		    PORTB,0
    call	    Delay900
    GOTO Loop
```

The `START`-Routine is where things go together. The second statement calls the previously discussed `Initialize`-routine so that we can use the digital pin 0 directly in line three. But at this point we first define a new subroutine called `Loop` so that we can jump to this point later. We use `bsf` to turn on a LED and `bcf` to turn it off again. Between the two calls we use the discussed calls to `DelayW` and `Delay900`. The last statement `GOTO Loop` is responsible for the endless loop that we need for the desired behaviour.

## LED Shifter (Assembler-Version)

Due to missing time during the lesson we had to complete this project alone at home.  
It was the target to subsequently turn on all pins on one port according to the following image.
![](LED-Shifter.png)

### 1. Initialize for the LED-Shifter

The code necessarry for this application is nearly the same as that used in the Hello, World application.

```assembler
Initialize    
    movlw   0b00000000
    movwf   TRISB
    movlw   0b00000001
    movwf   PORTB
    return
```

In this case we need to use the whole bunch of pins provided by port b. As we need all to be outputs we load a byte with all bits set to 0 first into the accumulator and from there into the control register for trisistor b. Now that we have all pins in the correct mode we begin by loading the first correct state into the data register of port b. The first state is represented by the byte `0b00000001` as the LSB represents the first pin of the port.

### 2. StepUp & StepDown

`StepUp` and `StepDown` are two methods that move the active led one step to the left or to the right respectively. Both methods utilize a modified version of the `Delay900` method described earlier. As they are pretty similar I will show how they work with `StepUp` as an example.

```assembler
StepUp 
    rlncf    PORTB,1    ;   StepDown uses rrncf respectively
    call     Delay500
    return
```

Allthough this method looks pretty simple it introduced the first problems. It was a hint to use `rlf` as I tried to use that statement over `rlncf` I got compiler error but had problems understanding them. After countless useless answers in many forum threads I found out, that `rlf` is called `rlcf` in the instruction set used by the `PIC18F4520` microcontroller we are targeting here.
But as I had replaced the calls I noticed that on the one hand the LEDs will turn on subsequently as they should but on the other hand they didn't turn off as they should. I figured out, that the reason for that was the carrying behaviour of that instruction. I found another called `rlncf` which does the job pretty god as it doesnt care if whether an overflow happens.

### 3. Configuration

Another problem I encountered was that some pins were initilized as analog rather than digita outputs. For some reason I wasn't able to see outputs on those pins. The solution was it to change the configuration with

```assembler
CONFIG  PBADEN = OFF
```

### 4. Shift the LEDs

As a first approach I went with a rather primitive solution to the problem as I took the boilerplate code from the first application, implemented the methods described above and added 14 method calls like so

```assembler
START
    call    Initialize
    Loop		    
    call    StepUp      ;   repeat six times
    call    StepDown    ;   repeat six times
    GOTO    Loop
```

The next was to reduce steps by using logic to determine the direction of the animation. I tried to solve the problem with the following (not working) snippet (I introduced two new help registers `Logic_Temp1` and `Logic_Temp2`). 

```assembler
btfss   ShiftLeft,0	    ; if ShiftLeft[0] == 0 {
call    StepUp	        ;   StepUp();
                        ; }

btfsc   ShiftLeft,0	    ; if ShiftLeft[0] == 1 {
call    StepDown        ;   StepDown();
                        ; }

movlw   0b00000001
btfsc   LATB,7	        ; W = LATB[7] == 1 ? 0b00000001 : 0b00000000
movlw   0b00000000
andwf   ShiftLeft,0	    ; W = (shiftLeft == 1 && LATB != 0b10000000)
movwf   Logic_Temp1	    ; Logic_Temp1 = (shiftLeft == 1 && LATB != 0b10000000)

movlw   0b00000001
btfss   LATB,0	        ; W = LATB[0] == 1 ? 0b00000001 : 0b00000000
movlw   0b00000000
movwf   Logic_Temp2
comf    ShiftLeft,0	    ; W = !ShiftLeft
andwf   Logic_Temp2,1   ; Logic_Temp2 = (shiftLeft == 0 && LATB != 0b00000001)

movf    Logic_Temp1
iorwf   Logic_Temp2,0   ; W = (shiftLeft == 1 && LATB != 0b10000000) || (shiftLeft == 0 && LATB != 0b00000001)
movwf   ShiftLeft    
```

As I think, that the concept itself should work and there are just some minor bugs like swapped literals, the amount of code should not change anymore. But what we also can see is that for the basic solution we need 14 calls (and as we also call them in the second aproach their cost can be simplified to 1). The second however takes 18 calls and is very hard to understand. For that reason I will stick to the first approach as it is (at least in my opinion) a greater value to be able to understand the code you wrote.

## Hello, World (C-Version)

As a first project in C we had to clone the "Hello, World" we did in assembler. Allthough that is relatively simple to program, I had some problems getting even an empty `main` to compile. The problem was, that MPLABX couldn't find a file called `xc.h`. After a lot of time I figured out, that I had to update the projects settings to include some folders. From now I was able to implement the project myself. We discussed how to use a configuration generator to generate some code in order to configure the microcontroller in a propper way. The results were placed in a header file called `definitions.h`.
To make my code more readable I defined two aliases for the value of the first pin on port b and the corresponding trisistor. As I figured our later we also needed to define the frequency of the used crystal for the delay methods to work.

```c
#define _XTAL_FREQ 4000000
#define LED LATBbits.LATB0
#define LEDMode TRISBbits.RB0
```

With the aliases beeing set I was able to set the pin mode and state quite simple just by allocating a 0 to `LEDMode` and `LED`.

```c
void main(void) {
    LEDMode = 0;
    LED = 0;
    while(1) {
        LED = 1;
        __delay_ms(100);
        LED = 0;
        __delay_ms(900);
    }
    return;
}
```

I used the I/O Pins view in order to check my results and saw that the pin was blinking just as expected, allthough I'm not quite sure whether the timing is correct nor if it is even consistently wrong.
