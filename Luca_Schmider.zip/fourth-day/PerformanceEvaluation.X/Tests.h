void calculation(void);
void trigonometry(void);