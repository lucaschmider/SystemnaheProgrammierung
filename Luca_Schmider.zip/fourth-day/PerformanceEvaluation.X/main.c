/*
 * File:   main.c
 * Author: lucas
 *
 * Created on 24. Februar 2021, 15:58
 */



#include <xc.h>
#include "Tests.h"

void main(void) {
    /*while(1) {
        calculation();
    }*/
    trigonometry();
    return;
}

